package com.neu.reviewerfinder.test;
import com.neu.reviewerfinder.ui.UI;

public interface Job {
	public boolean testJob(UI<?> request);
}
