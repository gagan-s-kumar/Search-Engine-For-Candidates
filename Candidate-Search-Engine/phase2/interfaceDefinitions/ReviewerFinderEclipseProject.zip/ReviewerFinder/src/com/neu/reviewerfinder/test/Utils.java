package com.neu.reviewerfinder.test;

public interface Utils {
	public boolean testUtil(Class<?> obj);
}
